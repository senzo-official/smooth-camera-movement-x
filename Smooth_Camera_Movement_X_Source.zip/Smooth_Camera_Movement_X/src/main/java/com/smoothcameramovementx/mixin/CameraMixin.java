package com.smoothcameramovementx.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Camera.class)
public abstract class CameraMixin {
    @Shadow
    public abstract boolean isThirdPerson();

    @Shadow
    public abstract float getYaw();

    @Shadow
    public abstract float getPitch();

    @Shadow
    protected abstract void setRotation(float yaw, float pitch);

    private boolean scmx$hasPreviousRotation = false;
    private float scmx$smoothYaw;
    private float scmx$smoothPitch;

    @Inject(method = "update", at = @At("TAIL"))
    private void scmx$smoothThirdPersonRotation(CallbackInfo ci) {
        if (!this.isThirdPerson()) {
            scmx$hasPreviousRotation = false;
            return;
        }

        float targetYaw = this.getYaw();
        float targetPitch = this.getPitch();

        if (!scmx$hasPreviousRotation) {
            scmx$smoothYaw = targetYaw;
            scmx$smoothPitch = targetPitch;
            scmx$hasPreviousRotation = true;
            return;
        }

        // A gentle, frame-rate-independent smoothing factor.
        // The shortest angular path prevents snapping when yaw crosses +/-180 degrees.
        float factor = 1.0F - (float) Math.pow(0.78D, 60.0D / 60.0D);
        float yawDifference = MathHelper.wrapDegrees(targetYaw - scmx$smoothYaw);

        scmx$smoothYaw += yawDifference * factor;
        scmx$smoothPitch += (targetPitch - scmx$smoothPitch) * factor;

        this.setRotation(scmx$smoothYaw, scmx$smoothPitch);
    }
}
