# Smooth Camera Movement X

A client-side Fabric mod for Minecraft Java 1.21.11.

## Feature
Automatically smooths camera rotation in third-person view. First-person view is left unchanged. No GUI, settings screen, or keybinds.

## Build
The included GitHub Actions workflow builds the mod with Java 21. Open the repository's **Actions** tab and download the artifact from a successful workflow run.

## Install
Place the built JAR in the `mods` folder of a Minecraft 1.21.11 Fabric profile. This is a client-side mod.
